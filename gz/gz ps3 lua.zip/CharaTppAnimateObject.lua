--[[FDOC
	@id CharaAnimateObject
	@category Script Character 
	@brief 指定モーションを再生するオブジェクト
]]--
CharaTppAnimateObject = {

}
