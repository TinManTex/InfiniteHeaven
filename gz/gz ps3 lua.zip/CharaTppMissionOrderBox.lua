--------------------------------------------------------------------------------
--! @file	CharaTppMissionOrderBox.lua
--! @brief	ミッション受注箱
--------------------------------------------------------------------------------

CharaTppMissionOrderBox = {

} -- CharaTppDestructionObject
