--------------------------------------------------------------------------------
--! @file	TppGadgetUtility.lua
--! @brief	ギミック(Gadget)関連のユーティリティ Lua 関数群
--------------------------------------------------------------------------------

TppGadgetUtility = {

-- ギミック共通プラグイン追加
AddGadgetCommonPlugin = function( chara , animgraph)
end,

} -- TppGadgetUtility
