TppSystemUtilityEvents = {

PadConfigUpdate = function()
	TppSystemUtility.ConfigDefaultPadAssigns()
end,

}
