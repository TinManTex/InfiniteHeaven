--ロケーション情報初期化
--GZ

LocationManager.RegisterLocationInformation(39,3,"/Assets/tpp/pack/ui/gz/title_datas.fpk") --title
LocationManager.RegisterLocationInformation(38,3,"/Assets/tpp/pack/ui/gz/title_datas.fpk") --ending
LocationManager.RegisterLocationInformation(40,1,"/Assets/tpp/pack/location/gntn/gntn.fpk") 
LocationManager.RegisterLocationInformation(45,1,"/Assets/tpp/pack/location/ombs/ombs.fpk")
